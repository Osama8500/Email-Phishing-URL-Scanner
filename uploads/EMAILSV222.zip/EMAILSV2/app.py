from flask import Flask, render_template, request
import joblib, re, numpy as np
from urllib.parse import urlparse
from feature import FeatureExtraction

app = Flask(__name__)

# تحميل النماذج
msg_model = joblib.load('spam_model.pkl')
vectorizer = joblib.load('vector.pkl')
url_model = joblib.load('newmodel.pkl')

# استخراج روابط
url_pattern = re.compile(r'(https?://\S+|www\.\S+)')

# قائمة كلمات وعبارات السبام
spam_keywords = [
    '$$$', '€€€', '£££', '50% off', 'A few bob', 'Accept cash cards', 'Accept credit cards', 'Affordable',
    'Affordable deal', 'Avoid bankruptcy', 'Bad credit', 'Bank', 'Bankruptcy', 'Bargain', 'Billing',
    'Billing address', 'Billion', 'Billion dollars', 'Billionaire', 'Card accepted', 'Cards accepted',
    'Cash', 'Cash bonus', 'Cash out', 'Cash-out', 'Cashcashcash', 'Casino', 'Cents on the dollar', 'Check',
    'Check or money order', 'Claim your discount', 'Cost', 'Costs', 'Credit', 'Credit bureaus', 'Credit card',
    'Credit card offers', 'Credit or Debit', 'Deal', 'Debt', 'Discount', 'Dollars', 'Double your',
    'Double your wealth', 'Earn', 'Earn $', 'Earn cash', 'Earn extra income', 'Earn from home',
    'Earn monthly', 'Earn per month', 'Earn per week', 'Earn per year', 'Easy income', 'Easy terms',
    'F r e e', 'For free', 'For just $', 'Free access', 'Free consultation', 'Free gift', 'Free hosting',
    'Free info', 'Free investment', 'Free membership', 'Free money', 'Free preview', 'Free quote',
    'Free trial', 'Full refund', 'Get out of debt', 'Giveaway', 'Guaranteed deposit', 'Increase revenue',
    'Increase sales/traffic', 'Instant earnings', 'Instant income', 'Insurance', 'Investment',
    'Investment advice', 'Loans', 'Make $', 'Money-back guarantee', 'Mortgage', 'Mortgage rates', 'Offer',
    'One hundred percent free', 'Only $', 'Price', 'Price protection', 'Profits', 'Quote', 'Refinance',
    'Save $', 'Save big money', 'Subject to credit', 'US Dollars', 'Why pay more?', 'Your income',
    '100% guaranteed', 'Access now', 'Act fast', 'Amazing deal', 'Apply now', 'As seen on', 'Best deal',
    'Big profit', 'Can’t miss', 'Click below', 'Click here', 'Deal ending soon', 'Don’t delete',
    'Double your money', 'Exclusive deal', 'Fantastic offer', 'Free membership', 'Get it now', 'Great news',
    'Guaranteed results', 'Important information', 'Increase sales', 'Instant savings', 'Limited time',
    'Must read', 'New customers only', 'No catch', 'No cost', 'No credit check', 'No obligation',
    'No strings attached', 'Once in a lifetime', 'Only available here', 'Order now', 'Potential earnings',
    'Pure profit', 'Risk-free', 'Special invitation', 'Special offer', 'This won’t last', 'Urgent',
    '#1', '100% free', '100% off', '100% satisfied', 'Additional income', 'Amazed', 'Amazing',
    'Amazing deal', 'Amazing offer', 'Amazing stuff', 'Be amazed', 'Be surprised', 'Be your own boss',
    'Best bargain', 'Best offer', 'Best price', 'Best rates', 'Big bucks', 'Bonus', 'Can’t live without',
    'Consolidate debt', 'Double your cash', 'Double your income', 'Drastically reduced', 'Earn extra cash',
    'Earn money', 'Expect to earn', 'Extra', 'Extra cash', 'Extra income', 'Fantastic', 'Fantastic deal',
    'Fantastic offer', 'Fast cash', 'Financial freedom', 'Free priority mail', 'Get paid', 'Incredible deal',
    'Join millions', 'Lowest price', 'Make money', 'Million dollars', 'Money-back guarantee', 'Prize',
    'Promise', 'Pure profit', 'Risk-free', 'Satisfaction guaranteed', 'Save up to', 'Special promotion',
    'The best', 'Thousands', 'Unbeatable offer', 'Unbelievable', 'Unlimited', 'Wonderful',
    'Access', 'Access now', 'Act', 'Act immediately', 'Act now', 'Action', 'Action required', 'Apply here',
    'Apply online', 'Become a member', 'Before it’s too late', 'Being a member', 'Buy', 'Buy direct',
    'Buy now', 'Buy today', 'Call', 'Call free', 'Call me', 'Call now', 'Can we have a minute of your time?',
    'Cancel now', 'Cancellation required', 'Claim now', 'Click me to download', 'Contact us immediately',
    'Deal ending soon', 'Do it now', 'Do it today', 'Don’t hesitate', 'Don’t waste time', 'Exclusive deal',
    'Expires today', 'Final call', 'For instant access', 'For Only', 'For you', 'Friday before [holiday]',
    'Get started', 'Great offer', 'Hurry up', 'Immediately', 'Info you requested', 'Information you requested',
    'Instant', 'Limited time', 'Now', 'Offer expires', 'Once in lifetime', 'Only', 'Order today',
    'Please read', 'Purchase now', 'Sign up free', 'Sign up free today', 'Supplies are limited', 'Take action',
    'Take action now', 'This won’t last', 'Time limited', 'Today', 'Top urgent', 'Trial', 'Urgent',
    'What are you waiting for?', 'While supplies last', 'You are a winner', '100% natural', 'All natural',
    'Best price', 'Certified organic', 'Clinical trial', 'Cure for', 'Diet pill', 'Doctor recommended',
    'Double blind study', 'Fat burner', 'Fast weight loss', 'Free antivirus', 'Free consultation',
    'Get slim', 'Guaranteed weight loss', 'Hair growth', 'Lose weight fast', 'Medical breakthrough',
    'Miracle cure', 'Money-back guarantee', 'Natural remedy', 'No prescription needed', 'Online pharmacy',
    'Over-the-counter', 'Pain relief', 'Prescription drugs', 'Reverse aging', 'Safe and effective',
    'Scientifically proven', 'Secret formula', 'Weight loss', 'Youthful skin', 'Account update',
    'Action required', 'Activate now', 'Antivirus', 'Change password', 'Click to verify',
    'Confirm your details', 'Final notice', 'Improve security', 'Install now', 'Last warning',
    'Log in now', 'New login detected', 'Online account', 'Password reset', 'Payment details needed',
    'Phishing alert', 'Secure payment', 'Security breach', 'Security update', 'Update account',
    'Verify identity', 'Warning message', 'Adult content', 'Bet now', 'Big win', 'Blackjack',
    'Casino bonus', 'Cash out now', 'Click to win', 'Double your money', 'Exclusive access',
    'Free chips', 'Free spins', 'Gamble online', 'Hot deal', 'Instant winnings', 'Jackpot',
    'Live dealer', 'Lottery winner', 'Lucky chance', 'Online betting', 'Online casino', 'Onlinegaming',
    'Poker tournament', 'Risk-free bet', 'Slots jackpot', 'Spin to win', 'Try for free',
    'VIP offer', 'Winner announced', 'Winning numbers', 'XXX'
]

def extract_urls(text):
    return url_pattern.findall(text)

def remove_urls(text):
    return url_pattern.sub('', text)

def check_homograph_tld(url):
    domain = urlparse(url).netloc.lower()
    if 'xn--' in domain:
        return 'punycode homograph detected'
    tld = domain.split('.')[-1]
    if len(tld) > 3:
        return f'unusual TLD .{tld}'
    return None

def check_url_model(url):
    feats = FeatureExtraction(url).getFeaturesList()
    n = url_model.n_features_in_
    feats = (feats + [0] * n)[:n]
    x = np.array(feats).reshape(1, n)
    pred = url_model.predict(x)[0]
    proba = None
    if hasattr(url_model, 'predict_proba'):
        probs = url_model.predict_proba(x)[0]
        proba = probs[1]
    return pred, proba

def explain_with_lime(text):
    from lime.lime_text import LimeTextExplainer
    explainer = LimeTextExplainer(class_names=['Ham', 'Spam'])
    
    def predict_proba(texts):
        vecs = vectorizer.transform(texts)
        return msg_model.predict_proba(vecs)
    
    exp = explainer.explain_instance(text, predict_proba, num_features=5)
    return exp.as_list()

def check_spam_keywords(text):
    found_keywords = []
    text_lower = text.lower()
    for keyword in spam_keywords:
        if keyword.lower() in text_lower:
            found_keywords.append(keyword)
    return found_keywords

@app.route('/', methods=['GET', 'POST'])
def index():
    result = None
    reasons = []
    extracted_urls = []
    url_results = []
    spam_keywords_found = []

    if request.method == 'POST':
        content = request.form.get('email', '').strip()
        if content:
            # 1. تحليل الكلمات المفتاحية للسبام
            spam_keywords_found = check_spam_keywords(content)
            if spam_keywords_found:
                reasons.append(f"تم اكتشاف كلمات سبام: {', '.join(spam_keywords_found)}")

            # 2. تحليل النص
            extracted_urls = extract_urls(content)
            text_no_urls = remove_urls(content)

            X = vectorizer.transform([text_no_urls])
            pred_txt = msg_model.predict(X)[0]
            text_result = 'Spam' if pred_txt == 1 else 'Ham'
            reasons.append(f"تحليل النص: {text_result}")

            # تفسير LIME
            for feat, w in explain_with_lime(text_no_urls):
                reasons.append(f"تفسير النموذج: '{feat}' → {w:.2f}")

            # 3. فحص الروابط
            url_spam_detected = False
            for u in extracted_urls:
                hom = check_homograph_tld(u)
                if hom:
                    url_results.append({'url': u, 'result': 'Spam', 'reason': hom, 'confidence': 1.0})
                    url_spam_detected = True
                    break
                
                p, pr = check_url_model(u)
                if pr is not None:
                    url_result = 'Ham' if pr >= 0.5 else 'Spam'
                    url_results.append({'url': u, 'result': url_result, 'reason': f'نسبة الثقة: {pr:.2f}', 'confidence': pr})
                    if pr < 0.5:
                        url_spam_detected = True
                else:
                    url_result = 'Ham' if p == 0 else 'Spam'
                    confidence = 0.9 if p == 1 else 0.1
                    url_results.append({'url': u, 'result': url_result, 'reason': 'تحليل بدون نسبة ثقة', 'confidence': confidence})
                    if p == 1:
                        url_spam_detected = True

            # تحديد النتيجة النهائية
            if text_result == 'Spam' or url_spam_detected or spam_keywords_found:
                result = 'Spam'
            else:
                result = 'Ham'
        else:
            result = 'Ham'

    return render_template('index.html',
                         result=result,
                         urls=extracted_urls,
                         url_results=url_results,
                         reasons=reasons,
                         spam_keywords_found=spam_keywords_found)

if __name__ == '__main__':
    app.run(debug=True)